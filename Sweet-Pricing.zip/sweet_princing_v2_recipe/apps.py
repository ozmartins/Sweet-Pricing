from django.apps import AppConfig

class PrecoDoceV2RecipeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sweet_princing_v2_recipe'
